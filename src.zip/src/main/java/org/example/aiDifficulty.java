package org.example;

public enum aiDifficulty {
    EASY, MEDIUM, HARD
}
