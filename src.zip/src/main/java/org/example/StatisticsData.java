package org.example;

public class StatisticsData {
    public int gamesPlayed;
    public int easyWins;
    public int easyLosses;
    public int mediumWins;
    public int mediumLosses;
    public int hardWins;
    public int hardLosses;
}
